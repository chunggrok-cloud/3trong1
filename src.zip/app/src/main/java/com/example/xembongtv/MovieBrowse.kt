package com.example.xembongtv

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.net.URLEncoder

// Giao diện chọn phim kiểu FPT Play: thanh biểu tượng bên trái, banner theo phim đang chọn,
// các hàng phim có tiêu đề, trang thể loại, tìm kiếm. Dữ liệu đọc từ trang 500phim bằng WebView ẩn.
class MovieBrowse(
    private val act: AppCompatActivity,
    private val unit: Float,
    private val js: String,
    private val movieUrl: () -> String,
    private val configure: (WebView) -> Unit,
    private val blocked: (String) -> Boolean,
    private val onOpen: (String) -> Unit,
    private val onRecent: (String) -> Unit,
    private val onLogin: () -> Unit,
    private val getCred: () -> Pair<String, String>?
) {
    class Item(val title: String, val url: String, val poster: String, val label: String, val progress: Double)
    class Row(val title: String, val more: String, val items: List<Item>)
    class Genre(val name: String, val url: String)

    private enum class V { HOME, GENRES, LIST }
    private enum class Kind { HOME, LIST }

    private fun px(v: Int): Int = (v * unit).toInt()
    private val ui = Handler(Looper.getMainLooper())

    val view = FrameLayout(act)
    private lateinit var bscr: WebView
    private var bscrReady = false

    private val bg = Color.parseColor("#0B0F17")
    private val accent = Color.parseColor("#4FC3F7")

    // dữ liệu
    private var rows: List<Row> = emptyList()
    private var genres: List<Genre> = emptyList()
    private var searchAction = ""
    private var searchName = ""
    private var listItems: List<Item> = emptyList()
    private var listTitle = ""
    private var listNext = ""
    private var loadedAt = 0L
    private var cur = V.HOME
    private var listFrom = V.HOME

    // giao diện
    private val rail = LinearLayout(act)
    private val railIcons = ArrayList<RailIcon>()
    private val content = FrameLayout(act)
    private val homeRv = RecyclerView(act)
    private val homeAdapter = HomeAdapter()
    private val homeLm = LinearLayoutManager(act)
    private val genrePane = LinearLayout(act)
    private val genreRv = RecyclerView(act)
    private val genreAdapter = TileAdapter()
    private val listPane = LinearLayout(act)
    private val listRv = RecyclerView(act)
    private val listAdapter = GridAdapter()
    private val listTitleView = TextView(act)
    private val listSubView = TextView(act)
    private val statusView = TextView(act)

    // banner
    private var heroBackdrop: ImageView? = null
    private var heroTag: TextView? = null
    private var heroTitle: TextView? = null
    private var heroMeta: TextView? = null
    private var heroItem: Item? = null
    private var heroRowTitle = ""

    private var gen = 0
    private var curRow = 1
    private var lastFocus: View? = null

    val hasData: Boolean get() = rows.isNotEmpty()

    init {
        view.setBackgroundColor(bg)
        buildRail()
        buildHome()
        buildGenres()
        buildList()
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        lp.leftMargin = px(48)
        view.addView(content, lp)
        view.addView(rail, FrameLayout.LayoutParams(px(48), ViewGroup.LayoutParams.MATCH_PARENT))
        statusView.setTextColor(Color.parseColor("#8FA3BF"))
        statusView.setTextSize(TypedValue.COMPLEX_UNIT_PX, 18f * unit)
        statusView.gravity = Gravity.CENTER
        statusView.visibility = View.GONE
        view.addView(statusView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        showPane(V.HOME)
    }

    // ------------------------------------------------------------------ vào / ra
    fun show() {
        view.visibility = View.VISIBLE
        val fresh = rows.isNotEmpty() && System.currentTimeMillis() - loadedAt < 10 * 60 * 1000L
        if (!fresh) reload()
        focusBack()
    }

    fun hide() {
        view.visibility = View.GONE
        gen++
        if (bscrReady) try { bscr.loadUrl("about:blank") } catch (e: Exception) {}
    }

    fun destroy() {
        gen++
        if (bscrReady) {
            try { view.removeView(bscr) } catch (e: Exception) {}
            try { bscr.destroy() } catch (e: Exception) {}
            bscrReady = false
        }
    }

    fun reload() {
        rows = emptyList()
        heroItem = null
        lastFocus = null
        homeAdapter.rebuild()
        loadFrom(movieUrl(), Kind.HOME)
    }

    // Back: trả true nếu đã tự xử lý (đóng trang thể loại / kết quả)
    fun onBack(): Boolean {
        return when (cur) {
            V.LIST -> { showPane(if (listFrom == V.GENRES) V.GENRES else V.HOME); focusBack(); true }
            V.GENRES -> { showPane(V.HOME); focusBack(); true }
            V.HOME -> false
        }
    }

    private fun focusBack() {
        view.post {
            val v = lastFocus
            if (v != null && v.isAttachedToWindow && v.visibility == View.VISIBLE && cur == V.HOME) { v.requestFocus(); return@post }
            when (cur) {
                V.HOME -> focusRow(1, 0)
                V.GENRES -> genreRv.post { genreRv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
                V.LIST -> listRv.post { listRv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
            }
            if (rows.isEmpty() && railIcons.isNotEmpty()) railIcons[0].requestFocus()
        }
    }

    // ------------------------------------------------------------------ đọc trang bằng WebView ẩn
    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView() {
        if (bscrReady) return
        bscr = WebView(act).apply { visibility = View.INVISIBLE }
        configure(bscr)
        bscr.settings.blockNetworkImage = true
        bscr.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val h = r.url.host ?: return null
                if (blocked(h)) return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                return null
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val s = r.url.scheme ?: return true
                return !(s == "http" || s == "https")
            }

            override fun onPageFinished(v: WebView, url: String?) {
                if (url == null || url == "about:blank") return
                val g = gen
                ui.postDelayed({ poll(g, 0) }, 400)
            }

            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: android.webkit.WebResourceError) {
                if (r.isForMainFrame) fail("Không tải được trang phim: " + e.description)
            }
        }
        view.addView(bscr, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        bscrReady = true
    }

    private var curKind = Kind.HOME

    private fun loadFrom(url: String, kind: Kind) {
        ensureWebView()
        gen++
        curKind = kind
        try { bscr.evaluateJavascript("window.__bs=0", null) } catch (e: Exception) {}
        if (kind == Kind.HOME && rows.isEmpty()) setStatus("Đang tải phim…")
        if (kind == Kind.LIST) setStatus("Đang tải…")
        bscr.stopLoading()
        bscr.loadUrl(url)
        val g = gen
        ui.postDelayed({ if (g == gen && statusView.visibility == View.VISIBLE && statusView.text.toString().startsWith("Đang")) poll(g, 0) }, 9000)
    }

    private var changedNow = false
    private var quiet = 0

    private fun totalItems(l: List<Row>): Int { var n = 0; for (r in l) n += r.items.size; return n }

    private fun poll(g: Int, tries: Int) {
        if (g != gen || !bscrReady) return
        if (tries == 0) quiet = 0
        changedNow = false
        bscr.evaluateJavascript(js) { raw ->
            if (g != gen) return@evaluateJavascript
            var ok = false
            var dbg = ""
            try {
                val s = org.json.JSONTokener(raw ?: "null").nextValue()
                if (s is String) {
                    val o = JSONObject(s)
                    dbg = o.optString("dbg")
                    ok = applyData(o)
                }
            } catch (e: Exception) {
                dbg = "lỗi đọc dữ liệu: " + e.message
            }
            // còn tải thêm hàng phim (trang tải trễ khi cuộn) thì quét tiếp, tối đa ~35 giây
            if (changedNow) quiet = 0 else quiet++
            val more = ok && tries < 24 && (tries < 3 || quiet < 4)
            if (more || (!ok && tries < 14)) ui.postDelayed({ poll(g, tries + 1) }, if (ok) 1400L else 800L)
            else if (!ok) fail("Không đọc được danh sách phim.\n$dbg")
        }
    }

    private fun parseItems(arr: org.json.JSONArray?): List<Item> {
        val out = ArrayList<Item>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val u = o.optString("url")
            if (u.isBlank()) continue
            out.add(Item(o.optString("title"), u, o.optString("poster"), o.optString("label"), o.optDouble("progress", 0.0)))
        }
        return out
    }

    // trả true nếu có dữ liệu dùng được
    private fun applyData(o: JSONObject): Boolean {
        val ra = o.optJSONArray("rows")
        val newRows = ArrayList<Row>()
        if (ra != null) {
            for (i in 0 until ra.length()) {
                val r = ra.optJSONObject(i) ?: continue
                val its = parseItems(r.optJSONArray("items"))
                if (its.isNotEmpty()) newRows.add(Row(r.optString("title"), r.optString("more"), its))
            }
        }
        val ga = o.optJSONArray("genres")
        if (ga != null && ga.length() > 0) {
            val gl = ArrayList<Genre>()
            for (i in 0 until ga.length()) {
                val g = ga.optJSONObject(i) ?: continue
                gl.add(Genre(g.optString("n"), g.optString("u")))
            }
            if (gl.isNotEmpty() && gl.size > genres.size) {
                val hadNone = genres.isEmpty()
                genres = gl
                genreAdapter.notifyDataSetChanged()
                if (hadNone && homeAdapter.itemCount > 2) homeAdapter.notifyItemChanged(2)
            }
        }
        val so = o.optJSONObject("search")
        if (so != null && so.optString("action").isNotBlank()) {
            searchAction = so.optString("action")
            searchName = so.optString("name")
        }
        if (curKind == Kind.HOME) {
            if (newRows.isEmpty()) return false
            publishRecent(newRows)
            if (rows.isEmpty()) {
                rows = newRows
                loadedAt = System.currentTimeMillis()
                setStatus(null)
                homeAdapter.rebuild()
                val first = rows[0].items.firstOrNull()
                if (first != null) setHero(first, rows[0].title)
                if (view.visibility == View.VISIBLE && cur == V.HOME) focusRow(1, 0)
                changedNow = true
                checkSession()
            } else if (newRows.size > rows.size) {
                // phần trang tải trễ: chỉ nối thêm hàng mới ở cuối, không đụng tới chỗ đang chọn
                val old = homeAdapter.itemCount
                rows = newRows
                homeAdapter.rebuildAppend(old)
                changedNow = true
            } else if (totalItems(newRows) > totalItems(rows) && homeRv.focusedChild == null) {
                // cùng số hàng nhưng có thêm phim (hoặc hàng gom lại khác): dựng lại khi chưa chọn gì
                rows = newRows
                homeAdapter.rebuild()
                changedNow = true
            }
            return true
        } else {
            val seen = HashSet<String>()
            val flat = ArrayList<Item>()
            for (r in newRows) for (it in r.items) if (seen.add(it.url)) flat.add(it)
            if (flat.isEmpty()) return false
            val first = listItems.isEmpty()
            if (first || (flat.size > listItems.size && listRv.focusedChild == null)) {
                listItems = flat
                listNext = o.optString("next")
                listAdapter.notifyDataSetChanged()
                listSubView.text = flat.size.toString() + " phim" + (if (listNext.isNotBlank()) " · còn trang sau" else "")
            }
            setStatus(null)
            if (cur != V.LIST) showPane(V.LIST)
            if (listRv.focusedChild == null) listRv.post { listRv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
            return true
        }
    }

    private var lastRecent = ""
    var recentFound = false
        private set

    // hàng "Xem tiếp" của trang phim -> gửi cho launcher (tối đa 6 phim)
    private fun publishRecent(list: List<Row>) {
        // chỉ gửi khi tìm thấy hàng "Xem tiếp": không xoá danh sách cũ của launcher nếu không đọc được
        val r = list.firstOrNull { it.title.lowercase().contains("xem tiếp") } ?: return
        recentFound = true
        updateLogin()
        val arr = org.json.JSONArray()
        for (x in r.items.take(6)) {
            arr.put(JSONObject().put("title", x.title).put("url", x.url).put("poster", x.poster)
                .put("progress", x.progress).put("label", x.label))
        }
        val j = arr.toString()
        if (j != lastRecent) {
            lastRecent = j
            try { onRecent(j) } catch (e: Exception) {}
        }
    }

    private fun fail(msg: String) {
        if (curKind == Kind.HOME && rows.isNotEmpty()) return
        if (curKind == Kind.LIST) {
            setStatus("Không tải được danh sách. Bấm Back để quay lại.")
            return
        }
        setStatus(msg + "\n\nBấm nút Vàng để tải lại, hoặc menu (nút Xanh lá) để mở trang web gốc.")
    }

    private fun setStatus(t: String?) {
        if (t == null) { statusView.visibility = View.GONE; return }
        statusView.text = t
        statusView.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ mở danh sách / tìm kiếm
    private fun openList(title: String, url: String, from: V) {
        listTitle = title
        listTitleView.text = title
        listSubView.text = "Đang tải…"
        listItems = emptyList()
        listNext = ""
        listAdapter.notifyDataSetChanged()
        listFrom = from
        showPane(V.LIST)
        loadFrom(url, Kind.LIST)
    }

    private fun doSearch(q: String) {
        val query = q.trim()
        if (query.isEmpty()) return
        val enc = URLEncoder.encode(query, "UTF-8")
        val url = if (searchAction.isNotBlank() && searchName.isNotBlank()) {
            searchAction + (if (searchAction.contains("?")) "&" else "?") + searchName + "=" + enc
        } else {
            movieUrl().trimEnd('/') + "/?s=" + enc
        }
        openList("Tìm: $query", url, cur)
    }

    private fun showSearchDialog() {
        val et = EditText(act).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, 20f * unit)
            setPadding(px(20), px(14), px(20), px(14))
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        val dialog = AlertDialog.Builder(act)
            .setTitle("Tìm phim")
            .setView(et)
            .setPositiveButton("Tìm") { _, _ -> doSearch(et.text.toString()) }
            .setNegativeButton("Hủy", null)
            .create()
        et.setOnEditorActionListener { _, _, _ -> doSearch(et.text.toString()); dialog.dismiss(); true }
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.show()
        et.requestFocus()
    }

    // ------------------------------------------------------------------ chuyển khung
    private fun showPane(v: V) {
        cur = v
        homeRv.visibility = if (v == V.HOME) View.VISIBLE else View.GONE
        genrePane.visibility = if (v == V.GENRES) View.VISIBLE else View.GONE
        listPane.visibility = if (v == V.LIST) View.VISIBLE else View.GONE
        for (i in railIcons.indices) railIcons[i].active = (i == 0 && v == V.GENRES) || (i == 2 && v == V.HOME)
        railIcons.forEach { it.invalidate() }
    }

    // ------------------------------------------------------------------ thanh bên trái
    private class RailIcon(val act: AppCompatActivity, val kind: Int, val unit: Float) : View(act) {
        var active = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val bgNormal = GradientDrawable().apply { cornerRadius = 8f * unit; setColor(Color.TRANSPARENT) }
        private val bgFocus = GradientDrawable().apply {
            cornerRadius = 8f * unit
            setColor(Color.parseColor("#22324D"))
            setStroke((2f * unit).toInt().coerceAtLeast(2), Color.parseColor("#4FC3F7"))
        }

        init {
            isFocusable = true
            isClickable = true
            background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_focused), bgFocus)
                addState(intArrayOf(), bgNormal)
            }
        }

        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            val w = width.toFloat()
            val h = height.toFloat()
            val cx = w / 2
            val cy = h / 2
            val s = minOf(w, h) * 0.22f
            p.color = if (isFocused) Color.WHITE else if (active) Color.parseColor("#4FC3F7") else Color.parseColor("#9FB0C8")
            p.strokeWidth = 2.2f * unit
            when (kind) {
                0 -> { // ☰
                    c.drawLine(cx - s, cy - s * 0.9f, cx + s, cy - s * 0.9f, p)
                    c.drawLine(cx - s, cy, cx + s, cy, p)
                    c.drawLine(cx - s, cy + s * 0.9f, cx + s, cy + s * 0.9f, p)
                }
                1 -> { // kính lúp
                    c.drawCircle(cx - s * 0.15f, cy - s * 0.15f, s * 0.8f, p)
                    c.drawLine(cx + s * 0.45f, cy + s * 0.45f, cx + s * 1.1f, cy + s * 1.1f, p)
                }
                else -> { // nhà
                    val path = Path()
                    path.moveTo(cx - s, cy)
                    path.lineTo(cx, cy - s)
                    path.lineTo(cx + s, cy)
                    path.moveTo(cx - s * 0.7f, cy - s * 0.2f)
                    path.lineTo(cx - s * 0.7f, cy + s)
                    path.lineTo(cx + s * 0.7f, cy + s)
                    path.lineTo(cx + s * 0.7f, cy - s * 0.2f)
                    c.drawPath(path, p)
                }
            }
        }
    }

    private fun buildRail() {
        rail.orientation = LinearLayout.VERTICAL
        rail.gravity = Gravity.CENTER_HORIZONTAL
        rail.setBackgroundColor(Color.parseColor("#0A0E15"))
        rail.setPadding(0, px(20), 0, 0)
        val acts = listOf<() -> Unit>(
            { showGenresPane() },
            { showSearchDialog() },
            { showPane(V.HOME); focusBack() }
        )
        for (i in 0..2) {
            val ic = RailIcon(act, i, unit)
            ic.setOnClickListener { acts[i]() }
            val lp = LinearLayout.LayoutParams(px(34), px(34))
            lp.bottomMargin = px(10)
            rail.addView(ic, lp)
            railIcons.add(ic)
        }
    }

    private fun showGenresPane() {
        if (genres.isEmpty()) {
            setStatus(if (rows.isEmpty()) "Đang tải phim…" else null)
            android.widget.Toast.makeText(act, "Chưa đọc được danh sách thể loại từ trang phim", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        showPane(V.GENRES)
        genreRv.post { genreRv.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    // ------------------------------------------------------------------ ảnh và thẻ phim
    private fun loadPoster(iv: ImageView, url: String, w: Int, h: Int) {
        if (url.isBlank()) { iv.setImageDrawable(null); return }
        val model = GlideUrl(
            url,
            LazyHeaders.Builder().addHeader("Referer", movieUrl()).addHeader("User-Agent", MainActivity.IMG_UA).build()
        )
        Glide.with(act).load(model).override(w, h).centerCrop().into(iv)
    }

    private fun roundOutline(iv: View, r: Float) {
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
        }
        iv.clipToOutline = true
    }

    private fun focusRing(): GradientDrawable = GradientDrawable().apply {
        cornerRadius = px(6).toFloat()
        setColor(Color.TRANSPARENT)
        setStroke(px(2).coerceAtLeast(3), Color.WHITE)
    }

    // thẻ phim dọc: poster + nhãn tập + thanh tiến độ + tên
    private fun makeCard(it: Item, onFocus: (View) -> Unit): LinearLayout {
        val cw = px(100)
        val ch = px(142)
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.isFocusable = true
        card.isClickable = true
        card.setPadding(px(3), px(3), px(3), px(3))
        card.layoutParams = ViewGroup.MarginLayoutParams(cw + px(6), ViewGroup.LayoutParams.WRAP_CONTENT)
        val frame = FrameLayout(act)
        val iv = ImageView(act)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setBackgroundColor(Color.parseColor("#151C28"))
        roundOutline(iv, px(6).toFloat())
        frame.addView(iv, FrameLayout.LayoutParams(cw, ch))
        if (it.label.isNotBlank()) {
            val b = TextView(act)
            b.text = it.label
            b.setTextColor(Color.WHITE)
            b.typeface = Typeface.DEFAULT_BOLD
            b.setTextSize(TypedValue.COMPLEX_UNIT_PX, 9f * unit)
            b.setPadding(px(4), px(1), px(4), px(1))
            b.background = GradientDrawable().apply { cornerRadius = px(3).toFloat(); setColor(Color.parseColor("#E53935")) }
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
            lp.topMargin = px(4); lp.rightMargin = px(4)
            frame.addView(b, lp)
        }
        if (it.progress > 0.0) {
            val bar = View(act)
            bar.setBackgroundColor(Color.parseColor("#FF5252"))
            val bw = (cw * it.progress.coerceIn(0.02, 1.0)).toInt()
            val bl = FrameLayout.LayoutParams(bw, px(3), Gravity.BOTTOM or Gravity.START)
            frame.addView(bar, bl)
        }
        val ring = View(act)
        ring.visibility = View.GONE
        ring.background = focusRing()
        frame.addView(ring, FrameLayout.LayoutParams(cw, ch))
        card.addView(frame, LinearLayout.LayoutParams(cw, ch))
        val t = TextView(act)
        t.text = it.title
        t.setTextColor(Color.parseColor("#CFD8E6"))
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 10.5f * unit)
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(px(2), px(4), px(2), 0)
        card.addView(t, LinearLayout.LayoutParams(cw, ViewGroup.LayoutParams.WRAP_CONTENT))
        loadPoster(iv, it.poster, cw, ch)
        card.setOnClickListener { _ -> onOpen(it.url) }
        card.setOnFocusChangeListener { v, has ->
            ring.visibility = if (has) View.VISIBLE else View.GONE
            t.setTextColor(if (has) Color.WHITE else Color.parseColor("#CFD8E6"))
            t.typeface = if (has) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            v.animate().scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f).setDuration(110).start()
            v.translationZ = if (has) 20f else 0f
            if (has) { lastFocus = v; onFocus(v) }
        }
        return card
    }

    // ------------------------------------------------------------------ trang chủ: banner + các hàng
    private fun setHero(it: Item, rowTitle: String) {
        heroItem = it
        heroRowTitle = rowTitle
        applyHero()
    }

    private var loginBtn: TextView? = null
    var loggedIn = false
        private set
    private var sessionChecked = false

    // đăng nhập bằng API của 500phim (NextAuth) ngay trong trình duyệt ẩn: cookie dùng chung với trang web của app
    fun login(email: String, pw: String, done: (Boolean, String) -> Unit, attempt: Int = 0) {
        ensureWebView()
        val u = bscr.url ?: ""
        if (!u.startsWith("http")) {
            if (attempt == 0) { bscr.stopLoading(); bscr.loadUrl(movieUrl()) }
            if (attempt < 20) ui.postDelayed({ login(email, pw, done, attempt + 1) }, 700) else done(false, "không tải được trang")
            return
        }
        val e = JSONObject.quote(email)
        val p = JSONObject.quote(pw)
        val code = "(function(){window.__loginRes=null;var set=function(o){window.__loginRes=JSON.stringify(o)};" +
            "fetch('/api/auth/csrf',{credentials:'include'}).then(function(r){return r.json()}).then(function(j){" +
            "var b=new URLSearchParams();b.append('email',$e);b.append('password',$p);b.append('csrfToken',j.csrfToken);b.append('callbackUrl',location.origin);b.append('json','true');" +
            "return fetch('/api/auth/callback/credentials',{method:'POST',credentials:'include',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:b.toString()});" +
            "}).then(function(r){return r.text()}).then(function(){return fetch('/api/auth/session',{credentials:'include'}).then(function(r){return r.json()});" +
            "}).then(function(s){set({ok:!!(s&&s.user),err:(s&&s.user)?'':'sai email hoặc mật khẩu'})}).catch(function(x){set({ok:false,err:String(x)})});return 1;})()"
        bscr.evaluateJavascript(code, null)
        pollLogin(0, done)
    }

    private fun pollLogin(n: Int, done: (Boolean, String) -> Unit) {
        ui.postDelayed({
            bscr.evaluateJavascript("window.__loginRes||null") { r ->
                if (r != null && r != "null") {
                    try {
                        val o = JSONObject(org.json.JSONTokener(r).nextValue() as String)
                        val ok = o.optBoolean("ok")
                        if (ok) { loggedIn = true; updateLogin() }
                        done(ok, o.optString("err"))
                    } catch (ex: Exception) { done(false, "lỗi đọc kết quả") }
                } else if (n < 30) pollLogin(n + 1, done)
                else done(false, "hết thời gian chờ")
            }
        }, 500)
    }

    // lần đầu có danh sách phim: kiểm tra đã đăng nhập chưa; hết phiên mà có tài khoản đã lưu thì tự đăng nhập lại
    private fun checkSession() {
        if (sessionChecked) return
        sessionChecked = true
        bscr.evaluateJavascript("(function(){window.__sess=null;fetch('/api/auth/session',{credentials:'include'}).then(function(r){return r.json()}).then(function(s){window.__sess=(s&&s.user)?1:0}).catch(function(){window.__sess=-1});return 1})()", null)
        ui.postDelayed({
            bscr.evaluateJavascript("window.__sess") { r ->
                when (r?.trim()) {
                    "1" -> { loggedIn = true; updateLogin() }
                    "0" -> {
                        val c = getCred()
                        if (c != null) login(c.first, c.second, { ok, _ -> if (ok) reload() })
                    }
                }
            }
        }, 2500)
    }

    private fun updateLogin() {
        loginBtn?.visibility = if (recentFound || loggedIn) View.GONE else View.VISIBLE
    }

    private fun applyHero() {
        updateLogin()
        val it = heroItem ?: return
        heroTag?.text = heroRowTitle
        heroTag?.visibility = if (heroRowTitle.isBlank()) View.GONE else View.VISIBLE
        heroTitle?.text = it.title
        val meta = StringBuilder()
        if (it.label.isNotBlank()) meta.append(it.label)
        if (it.progress > 0.0) {
            if (meta.isNotEmpty()) meta.append("  ·  ")
            meta.append("Đã xem ").append(Math.round(it.progress * 100)).append("%")
        }
        heroMeta?.text = meta.toString()
        val bd = heroBackdrop
        if (bd != null) loadPoster(bd, it.poster, px(260), px(170))
    }

    private fun buildHome() {
        homeRv.layoutManager = homeLm
        homeRv.adapter = homeAdapter
        homeRv.itemAnimator = null
        homeRv.clipToPadding = false
        homeRv.setPadding(0, 0, 0, px(60))
        homeRv.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        content.addView(homeRv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun scrollRowTo(pos: Int) {
        val target = if (pos <= 1) 0 else pos
        val sc = object : LinearSmoothScroller(act) {
            override fun getVerticalSnapPreference(): Int = LinearSmoothScroller.SNAP_TO_START
            override fun calculateSpeedPerPixel(d: android.util.DisplayMetrics): Float = 40f / d.densityDpi
        }
        sc.targetPosition = target
        homeLm.startSmoothScroll(sc)
    }

    private fun focusRow(pos: Int, col: Int) {
        if (pos < 1 || pos >= homeAdapter.itemCount) return
        curRow = pos
        scrollRowTo(pos)
        tryFocusRow(pos, col, 0)
    }

    private fun tryFocusRow(pos: Int, col: Int, n: Int) {
        val h = homeRv.findViewHolderForAdapterPosition(pos) as? RowVH
        if (h == null) {
            if (n < 25) homeRv.postDelayed({ tryFocusRow(pos, col, n + 1) }, 40)
            return
        }
        val rv = h.rv
        val cnt = rv.adapter?.itemCount ?: 0
        if (cnt == 0) return
        val c = minOf(col, cnt - 1)
        val v = rv.findViewHolderForAdapterPosition(c)?.itemView
        if (v != null) { v.requestFocus(); return }
        rv.scrollToPosition(c)
        rv.post { rv.findViewHolderForAdapterPosition(c)?.itemView?.requestFocus() }
    }

    private val GENRES_MARK = Any()

    private class RowVH(v: View, val title: TextView, val rv: RecyclerView) : RecyclerView.ViewHolder(v)
    private class HeroVH(v: View) : RecyclerView.ViewHolder(v)

    inner class HomeAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        // mỗi mục: null = banner; Row = hàng phim; Genre list = hàng thể loại
        private var entries: List<Any?> = listOf(null)

        private fun build(): List<Any?> {
            val l = ArrayList<Any?>()
            l.add(null)
            for ((i, r) in rows.withIndex()) {
                l.add(r)
                if (i == 0) l.add(GENRES_MARK)
            }
            return l
        }

        fun rebuild() {
            entries = build()
            notifyDataSetChanged()
        }

        fun rebuildAppend(oldCount: Int) {
            entries = build()
            if (entries.size > oldCount) notifyItemRangeInserted(oldCount, entries.size - oldCount)
        }

        fun isGenreRow(pos: Int): Boolean = pos in entries.indices && entries[pos] === GENRES_MARK

        override fun getItemCount(): Int = entries.size
        override fun getItemViewType(position: Int): Int = if (position == 0) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            if (viewType == 0) {
                val hv = FrameLayout(act)
                hv.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(170))
                val bd = ImageView(act)
                bd.scaleType = ImageView.ScaleType.CENTER_CROP
                bd.alpha = 0.55f
                heroBackdrop = bd
                val bl = FrameLayout.LayoutParams(px(260), px(170), Gravity.END)
                hv.addView(bd, bl)
                val scrim = View(act)
                scrim.background = GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(bg, bg, Color.TRANSPARENT)
                )
                hv.addView(scrim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                val bot = View(act)
                bot.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, bg))
                hv.addView(bot, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(60), Gravity.BOTTOM))
                val col = LinearLayout(act)
                col.orientation = LinearLayout.VERTICAL
                col.setPadding(px(28), px(34), px(28), 0)
                val tag = TextView(act)
                tag.setTextColor(Color.parseColor("#CFD8E6"))
                tag.setTextSize(TypedValue.COMPLEX_UNIT_PX, 10f * unit)
                tag.setPadding(px(6), px(2), px(6), px(2))
                tag.background = GradientDrawable().apply { cornerRadius = px(3).toFloat(); setColor(Color.parseColor("#26324A")) }
                val tt = TextView(act)
                tt.setTextColor(Color.WHITE)
                tt.typeface = Typeface.DEFAULT_BOLD
                tt.setTextSize(TypedValue.COMPLEX_UNIT_PX, 26f * unit)
                tt.maxLines = 2
                tt.ellipsize = TextUtils.TruncateAt.END
                val mt = TextView(act)
                mt.setTextColor(Color.parseColor("#B9C5D8"))
                mt.setTextSize(TypedValue.COMPLEX_UNIT_PX, 13f * unit)
                heroTag = tag; heroTitle = tt; heroMeta = mt
                val tl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                col.addView(tag, tl)
                val l2 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                l2.topMargin = px(6)
                col.addView(tt, l2)
                val l3 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                l3.topMargin = px(4)
                col.addView(mt, l3)
                hv.addView(col, FrameLayout.LayoutParams(px(330), ViewGroup.LayoutParams.WRAP_CONTENT))
                val lb = TextView(act)
                lb.text = "Đăng nhập"
                lb.setTextColor(Color.WHITE)
                lb.typeface = Typeface.DEFAULT_BOLD
                lb.setTextSize(TypedValue.COMPLEX_UNIT_PX, 14f * unit)
                lb.setPadding(px(18), px(9), px(18), px(9))
                lb.isFocusable = true
                lb.isClickable = true
                fun paint(f: Boolean) {
                    lb.background = GradientDrawable().apply {
                        cornerRadius = px(20).toFloat()
                        setColor(Color.parseColor(if (f) "#9575FF" else "#7C4DFF"))
                        if (f) setStroke(px(2), Color.WHITE)
                    }
                }
                paint(false)
                lb.setOnFocusChangeListener { _, f -> paint(f) }
                lb.setOnClickListener { onLogin() }
                lb.setOnKeyListener { _, code, e ->
                    if (e.action == KeyEvent.ACTION_DOWN && code == KeyEvent.KEYCODE_DPAD_DOWN) { focusRow(1, 0); true } else false
                }
                val llp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
                llp.topMargin = px(14)
                llp.rightMargin = px(24)
                hv.addView(lb, llp)
                loginBtn = lb
                applyHero()
                return HeroVH(hv)
            }
            val box = LinearLayout(act)
            box.orientation = LinearLayout.VERTICAL
            box.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            box.setPadding(px(28), px(8), 0, px(8))
            val t = TextView(act)
            t.setTextColor(Color.WHITE)
            t.typeface = Typeface.DEFAULT_BOLD
            t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 15f * unit)
            t.setPadding(px(3), 0, 0, px(6))
            box.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            val rv = RecyclerView(act)
            rv.layoutManager = LinearLayoutManager(act, LinearLayoutManager.HORIZONTAL, false)
            rv.itemAnimator = null
            rv.clipToPadding = false
            rv.setPadding(px(4), px(10), px(60), px(10))
            rv.isFocusable = false
            rv.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            box.addView(rv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return RowVH(box, t, rv)
        }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            if (holder is HeroVH) { applyHero(); return }
            holder as RowVH
            val e = entries[position]
            if (e is Row) {
                holder.itemView.visibility = View.VISIBLE
                holder.itemView.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                holder.title.text = if (e.title.isBlank()) "Phim" else e.title
                holder.rv.adapter = CardRowAdapter(e, position)
            } else {
                holder.title.text = "Thể loại"
                holder.rv.adapter = GenreRowAdapter(genres, position)
                holder.itemView.visibility = if (genres.isEmpty()) View.GONE else View.VISIBLE
                holder.itemView.layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    if (genres.isEmpty()) 0 else ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
        }
    }

    // phím lên/xuống giữa các hàng: giữ nguyên cột
    private fun rowKey(v: View, rowPos: Int, col: Int, code: Int, e: KeyEvent): Boolean {
        if (e.action != KeyEvent.ACTION_DOWN) return code == KeyEvent.KEYCODE_DPAD_DOWN || code == KeyEvent.KEYCODE_DPAD_UP
        when (code) {
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                var n = rowPos + 1
                if (homeAdapter.isGenreRow(n) && genres.isEmpty()) n++
                if (n < homeAdapter.itemCount) focusRow(n, col)
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                var n = rowPos - 1
                if (homeAdapter.isGenreRow(n) && genres.isEmpty()) n--
                if (n >= 1) focusRow(n, col)
                else if (loginBtn?.visibility == View.VISIBLE) { homeRv.scrollToPosition(0); loginBtn?.requestFocus() }
                return true
            }
        }
        return false
    }

    inner class CardRowAdapter(private val row: Row, private val rowPos: Int) : RecyclerView.Adapter<CardRowAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v)

        override fun getItemCount(): Int = row.items.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val fl = FrameLayout(act)
            fl.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            return VH(fl)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val fl = h.itemView as FrameLayout
            fl.removeAllViews()
            val it = row.items[position]
            val card = makeCard(it) { _ -> curRow = rowPos; setHero(it, row.title) }
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = px(10)
            fl.addView(card, lp)
            card.setOnKeyListener { v, code, e -> rowKey(v, rowPos, h.bindingAdapterPosition.coerceAtLeast(0), code, e) }
        }
    }

    private fun genreColor(name: String): Int {
        val pal = intArrayOf(0xFF8A4A5A.toInt(), 0xFF2F6FD0.toInt(), 0xFF1C2F6A.toInt(), 0xFF1F4A5A.toInt(), 0xFF4A3A28.toInt(), 0xFF4A6A9A.toInt(), 0xFF6A3A8A.toInt(), 0xFF2A6A4A.toInt())
        return pal[Math.abs(name.hashCode()) % pal.size]
    }

    private fun makeTile(g: Genre, w: Int): TextView {
        val t = TextView(act)
        t.text = g.name
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 13f * unit)
        t.gravity = Gravity.CENTER
        t.maxLines = 2
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(px(6), px(4), px(6), px(4))
        t.isFocusable = true
        t.isClickable = true
        val col = genreColor(g.name)
        val normal = GradientDrawable().apply { cornerRadius = px(6).toFloat(); setColor(col) }
        val focused = GradientDrawable().apply { cornerRadius = px(6).toFloat(); setColor(col); setStroke(px(2).coerceAtLeast(3), Color.WHITE) }
        t.background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), normal)
        }
        t.layoutParams = ViewGroup.MarginLayoutParams(w, px(52))
        t.setOnFocusChangeListener { v, has ->
            v.animate().scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f).setDuration(110).start()
            v.translationZ = if (has) 20f else 0f
            if (has) lastFocus = v
        }
        return t
    }

    inner class GenreRowAdapter(private val list: List<Genre>, private val rowPos: Int) : RecyclerView.Adapter<GenreRowAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v)

        override fun getItemCount(): Int = list.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val fl = FrameLayout(act)
            fl.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            return VH(fl)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val fl = h.itemView as FrameLayout
            fl.removeAllViews()
            val g = list[position]
            val tile = makeTile(g, px(110))
            val lp = FrameLayout.LayoutParams(px(110), px(52))
            lp.rightMargin = px(10)
            lp.topMargin = px(4)
            lp.bottomMargin = px(4)
            fl.addView(tile, lp)
            tile.setOnClickListener { openList(g.name, g.url, V.HOME) }
            tile.setOnFocusChangeListener { v, has ->
                v.animate().scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f).setDuration(110).start()
                v.translationZ = if (has) 20f else 0f
                if (has) { lastFocus = v; curRow = rowPos }
            }
            tile.setOnKeyListener { v, code, e -> rowKey(v, rowPos, h.bindingAdapterPosition.coerceAtLeast(0), code, e) }
        }
    }

    // ------------------------------------------------------------------ trang thể loại
    private fun buildGenres() {
        genrePane.orientation = LinearLayout.VERTICAL
        genrePane.setPadding(px(28), px(22), px(20), 0)
        val t = TextView(act)
        t.text = "Thể loại"
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, 24f * unit)
        genrePane.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        genreRv.layoutManager = GridLayoutManager(act, 6)
        genreRv.adapter = genreAdapter
        genreRv.itemAnimator = null
        genreRv.clipToPadding = false
        genreRv.setPadding(0, px(14), 0, px(40))
        genrePane.addView(genreRv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        content.addView(genrePane, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    inner class TileAdapter : RecyclerView.Adapter<TileAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v)

        override fun getItemCount(): Int = genres.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val fl = FrameLayout(act)
            fl.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(64))
            return VH(fl)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val fl = h.itemView as FrameLayout
            fl.removeAllViews()
            val g = genres[position]
            val tile = makeTile(g, ViewGroup.LayoutParams.MATCH_PARENT)
            val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(52))
            lp.setMargins(px(6), px(6), px(6), px(6))
            fl.addView(tile, lp)
            tile.setOnClickListener { openList(g.name, g.url, V.GENRES) }
        }
    }

    // ------------------------------------------------------------------ danh sách phim (thể loại / tìm kiếm)
    private fun buildList() {
        listPane.orientation = LinearLayout.VERTICAL
        listPane.setPadding(px(28), px(22), px(20), 0)
        listTitleView.setTextColor(Color.WHITE)
        listTitleView.typeface = Typeface.DEFAULT_BOLD
        listTitleView.setTextSize(TypedValue.COMPLEX_UNIT_PX, 24f * unit)
        listSubView.setTextColor(Color.parseColor("#8FA3BF"))
        listSubView.setTextSize(TypedValue.COMPLEX_UNIT_PX, 12f * unit)
        listPane.addView(listTitleView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        listPane.addView(listSubView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        listRv.layoutManager = GridLayoutManager(act, 6)
        listRv.adapter = listAdapter
        listRv.itemAnimator = null
        listRv.clipToPadding = false
        listRv.setPadding(0, px(14), 0, px(40))
        listPane.addView(listRv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        content.addView(listPane, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    inner class GridAdapter : RecyclerView.Adapter<GridAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v)

        override fun getItemCount(): Int = listItems.size + (if (listNext.isNotBlank() && listItems.isNotEmpty()) 1 else 0)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val fl = FrameLayout(act)
            fl.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(184))
            return VH(fl)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            val fl = h.itemView as FrameLayout
            fl.removeAllViews()
            if (position >= listItems.size) {
                val g = Genre("Trang sau  ›", listNext)
                val tile = makeTile(g, px(100))
                fl.addView(tile, FrameLayout.LayoutParams(px(100), px(60), Gravity.CENTER_HORIZONTAL or Gravity.TOP))
                tile.setOnClickListener { loadMoreList() }
                return
            }
            val it = listItems[position]
            val card = makeCard(it) { _ -> }
            fl.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.TOP))
        }
    }

    // trang kế: tải trang tiếp theo, nối vào danh sách
    private fun loadMoreList() {
        val u = listNext
        if (u.isBlank()) return
        val keep = listItems
        listSubView.text = "Đang tải trang sau…"
        gen++
        curKind = Kind.LIST
        val g = gen
        ensureWebView()
        try { bscr.evaluateJavascript("window.__bs=0", null) } catch (e: Exception) {}
        bscr.stopLoading()
        moreBase = keep
        bscr.loadUrl(u)
        ui.postDelayed({ if (g == gen) pollMore(g, 0) }, 4500)
    }

    private var moreBase: List<Item> = emptyList()

    private fun pollMore(g: Int, tries: Int) {
        if (g != gen || !bscrReady) return
        bscr.evaluateJavascript(js) { raw ->
            if (g != gen) return@evaluateJavascript
            var done = false
            try {
                val s = org.json.JSONTokener(raw ?: "null").nextValue()
                if (s is String) {
                    val o = JSONObject(s)
                    val ra = o.optJSONArray("rows")
                    val add = ArrayList<Item>()
                    if (ra != null) for (i in 0 until ra.length()) add.addAll(parseItems(ra.optJSONObject(i)?.optJSONArray("items")))
                    if (add.isNotEmpty()) {
                        val seen = HashSet<String>()
                        val merged = ArrayList<Item>()
                        for (x in moreBase) if (seen.add(x.url)) merged.add(x)
                        for (x in add) if (seen.add(x.url)) merged.add(x)
                        listItems = merged
                        listNext = o.optString("next")
                        listAdapter.notifyDataSetChanged()
                        listSubView.text = merged.size.toString() + " phim" + (if (listNext.isNotBlank()) " · còn trang sau" else "")
                        done = true
                    }
                }
            } catch (e: Exception) {
            }
            if (!done && tries < 8) ui.postDelayed({ pollMore(g, tries + 1) }, 900)
            else if (!done) listSubView.text = "Không tải được trang sau"
            else if (tries < 2) ui.postDelayed({ pollMore(g, tries + 1) }, 1400)
        }
    }
}
