package com.example.xembongtv

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Bàn phím trên màn hình của riêng app: dùng được khi TV không có bàn phím hệ thống. Mũi tên chọn phím, OK để gõ. */
class TvKeyboard(private val act: AppCompatActivity, private val unit: Float) {
    private fun px(v: Int): Int = (v * unit).toInt()

    private fun bgOf(color: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        cornerRadius = px(6).toFloat()
        setColor(color)
        if (stroke != 0) setStroke(px(2), stroke)
    }

    fun show(title: String, initial: String, password: Boolean, okLabel: String, onDone: (String) -> Unit): AlertDialog {
        val sb = StringBuilder(initial)
        var shift = false
        var sym = false
        var reveal = !password

        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(px(18), px(14), px(18), px(12))
        root.setBackgroundColor(Color.parseColor("#1c2230"))

        val tt = TextView(act)
        tt.text = title
        tt.setTextColor(Color.WHITE)
        tt.typeface = Typeface.DEFAULT_BOLD
        tt.setTextSize(TypedValue.COMPLEX_UNIT_PX, 18f * unit)
        root.addView(tt)

        val disp = TextView(act)
        disp.setTextColor(Color.WHITE)
        disp.setTextSize(TypedValue.COMPLEX_UNIT_PX, 20f * unit)
        disp.setPadding(px(12), px(10), px(12), px(10))
        disp.maxLines = 1
        disp.ellipsize = android.text.TextUtils.TruncateAt.START
        disp.background = bgOf(Color.parseColor("#0F1522"), Color.parseColor("#4FC3F7"))
        val dlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        dlp.topMargin = px(8)
        dlp.bottomMargin = px(10)
        root.addView(disp, dlp)

        val keys = LinearLayout(act)
        keys.orientation = LinearLayout.VERTICAL
        root.addView(keys)

        val dlg = AlertDialog.Builder(act).setView(root).create()

        fun refresh() {
            val t = if (reveal) sb.toString() else "•".repeat(sb.length)
            disp.text = t + "│"
        }

        lateinit var build: (String?) -> Unit

        fun key(label: String, w: Int, tag: String? = null, special: Boolean = false, action: () -> Unit): TextView {
            val k = TextView(act)
            k.text = label
            k.gravity = Gravity.CENTER
            k.typeface = Typeface.DEFAULT_BOLD
            k.setTextSize(TypedValue.COMPLEX_UNIT_PX, 16f * unit)
            k.setTextColor(Color.WHITE)
            k.isFocusable = true
            k.isClickable = true
            k.tag = tag
            val normal = bgOf(Color.parseColor(if (special) "#3A2F66" else "#26324A"))
            val foc = bgOf(Color.parseColor("#4FC3F7"), Color.WHITE)
            k.background = StateListDrawable().apply {
                addState(intArrayOf(android.R.attr.state_focused), foc)
                addState(intArrayOf(), normal)
            }
            k.setOnFocusChangeListener { v, f -> (v as TextView).setTextColor(if (f) Color.parseColor("#0B0F17") else Color.WHITE) }
            k.setOnClickListener { action() }
            val lp = LinearLayout.LayoutParams(px(w), px(38))
            lp.setMargins(px(3), px(3), px(3), px(3))
            k.layoutParams = lp
            return k
        }

        fun type(c: String) {
            sb.append(c)
            if (shift) { shift = false; build("shift") }
            refresh()
        }

        build = { focusTag ->
            keys.removeAllViews()
            val rows = if (sym) listOf("!#\$%&*+=?/", "()[]{}<>:;", "~^|\\'\"`,._", "0123456789")
            else listOf("1234567890", "qwertyuiop", "asdfghjkl@", "zxcvbnm._-")
            for (r in rows) {
                val row = LinearLayout(act)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_HORIZONTAL
                for (ch in r) {
                    val s = if (shift && ch.isLetter()) ch.uppercaseChar().toString() else ch.toString()
                    row.addView(key(s, 46) { type(s) })
                }
                keys.addView(row)
            }
            val b = LinearLayout(act)
            b.orientation = LinearLayout.HORIZONTAL
            b.gravity = Gravity.CENTER_HORIZONTAL
            if (!sym) b.addView(key(if (shift) "ABC" else "abc", 56, "shift", true) { shift = !shift; build("shift") })
            b.addView(key(if (sym) "ABC" else "#+=", 56, "sym", true) { sym = !sym; shift = false; build("sym") })
            b.addView(key("Cách", 96) { type(" ") })
            b.addView(key("Xóa", 62, null, true) { if (sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1); refresh() }.also {
                it.setOnLongClickListener { sb.setLength(0); refresh(); true }
            })
            if (password) b.addView(key(if (reveal) "Ẩn" else "Hiện", 56, "eye", true) { reveal = !reveal; build("eye"); refresh() })
            keys.addView(b)
            val a = LinearLayout(act)
            a.orientation = LinearLayout.HORIZONTAL
            a.gravity = Gravity.CENTER_HORIZONTAL
            a.addView(key("Hủy", 120, null, true) { dlg.dismiss() })
            a.addView(key(okLabel, 160, "ok") { dlg.dismiss(); onDone(sb.toString()) })
            keys.addView(a)
            val t = focusTag ?: "ok"
            keys.post {
                val f = keys.findViewWithTag<View>(t) ?: keys.getChildAt(1)
                f?.requestFocus()
            }
        }

        dlg.setOnKeyListener { _, code, e ->
            if (e.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            if (code == KeyEvent.KEYCODE_DEL) {
                if (sb.isNotEmpty()) sb.deleteCharAt(sb.length - 1)
                refresh()
                true
            } else if (e.isPrintingKey && !e.isCtrlPressed && !e.isAltPressed) {
                val u = e.unicodeChar
                if (u >= 32) { sb.append(u.toChar()); refresh(); true } else false
            } else false
        }

        refresh()
        build(null)
        dlg.show()
        dlg.window?.setLayout(px(580), android.view.WindowManager.LayoutParams.WRAP_CONTENT)
        return dlg
    }
}
