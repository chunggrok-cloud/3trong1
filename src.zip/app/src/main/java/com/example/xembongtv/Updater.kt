package com.example.xembongtv

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Tự cập nhật: đọc version.json trên GitHub Releases, tải APK mới, mở trình cài của Android. */
class Updater(private val act: Activity) {
    private val base = "https://github.com/chunggrok-cloud/3trong1/releases/download/latest/"

    private fun toast(t: String) = act.runOnUiThread { Toast.makeText(act, t, Toast.LENGTH_LONG).show() }

    private fun open(u: String): HttpURLConnection {
        var url = u
        for (i in 0 until 6) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "3in1-updater")
            val code = c.responseCode
            if (code in 300..399) {
                url = URL(URL(url), c.getHeaderField("Location")).toString()
                c.disconnect()
                continue
            }
            if (code != 200) throw RuntimeException("HTTP $code")
            return c
        }
        throw RuntimeException("redirect")
    }

    private fun curCode(): Int {
        val pi = act.packageManager.getPackageInfo(act.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else @Suppress("DEPRECATION") pi.versionCode
    }

    fun check(manual: Boolean) {
        Thread {
            try {
                val c = open(base + "version.json")
                val txt = c.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
                val o = JSONObject(txt)
                val code = o.getInt("versionCode")
                if (code > curCode()) {
                    val name = o.optString("versionName", code.toString())
                    val apk = o.optString("apk", base + "3in1.apk")
                    act.runOnUiThread { ask(name, apk) }
                } else if (manual) toast("Đang dùng bản mới nhất")
            } catch (e: Exception) {
                if (manual) toast("Không kiểm tra được bản mới (" + (e.message ?: "lỗi mạng") + ")")
            }
        }.start()
    }

    private fun ask(name: String, apk: String) {
        if (act.isFinishing) return
        AlertDialog.Builder(act)
            .setTitle("Có bản mới $name")
            .setMessage("Cập nhật ngay? Tải xong chỉ cần bấm Cài đặt.")
            .setPositiveButton("Cập nhật") { _, _ -> download(apk) }
            .setNegativeButton("Để sau", null)
            .show()
    }

    private fun download(apk: String) {
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            toast("Bật \"Cho phép từ nguồn này\" cho app, rồi mở lại app để cập nhật")
            try {
                act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName)))
            } catch (e: Exception) {}
            return
        }
        val dlg = AlertDialog.Builder(act).setTitle("Đang tải bản mới").setMessage("0%").setCancelable(false).create()
        dlg.show()
        Thread {
            try {
                val dir = File(act.cacheDir, "updates")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val f = File(dir, "3in1.apk")
                val c = open(apk)
                val total = c.contentLengthLong
                var got = 0L
                var last = 0
                c.inputStream.use { ins ->
                    f.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            got += n
                            if (total > 0) {
                                val pc = (got * 100 / total).toInt()
                                if (pc != last) { last = pc; act.runOnUiThread { dlg.setMessage("$pc%") } }
                            }
                        }
                    }
                }
                if (f.length() < 100_000) throw RuntimeException("file lỗi")
                act.runOnUiThread { dlg.dismiss(); install(f) }
            } catch (e: Exception) {
                act.runOnUiThread { dlg.dismiss() }
                toast("Tải thất bại: " + (e.message ?: "lỗi mạng"))
            }
        }.start()
    }

    private fun install(f: File) {
        try {
            val uri = FileProvider.getUriForFile(act, act.packageName + ".fileprovider", f)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/vnd.android.package-archive")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i)
        } catch (e: Exception) {
            toast("Không mở được trình cài: " + (e.message ?: ""))
        }
    }
}
