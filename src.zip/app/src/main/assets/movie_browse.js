(function () {
  // Đọc trang 500phim (trang chủ / thể loại / tìm kiếm) thành dữ liệu cho giao diện phim của app.
  // Chạy nhiều lần; trả về chuỗi JSON: {rows:[{title,more,items:[{title,url,poster,label,progress}]}], genres:[{n,u}], next, search:{action,name}, dbg}
  function norm(s) { return (s || '').replace(/\s+/g, ' ').trim(); }
  function abs(u) { try { return new URL(u, location.href).href; } catch (e) { return ''; } }
  var HOSTKEY = location.hostname.replace(/^www\./, '');
  function sameHost(u) {
    try { return new URL(u).hostname.replace(/^www\./, '') === HOSTKEY; } catch (e) { return false; }
  }
  function rect(el) { try { return el.getBoundingClientRect(); } catch (e) { return { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 }; } }
  function imgSrc(im) {
    var s = im.currentSrc || im.getAttribute('src') || '';
    if (!s || s.indexOf('data:') === 0) s = im.getAttribute('data-src') || im.getAttribute('data-original') || im.getAttribute('data-lazy-src') || '';
    if (!s || s.indexOf('data:') === 0) {
      var ss = im.getAttribute('srcset') || im.getAttribute('data-srcset') || '';
      if (ss) s = ss.split(',')[0].trim().split(' ')[0];
    }
    return (!s || s.indexOf('data:') === 0) ? '' : abs(s);
  }
  function bgOf(el) {
    var bg = '';
    try { bg = (el.style && el.style.backgroundImage) || getComputedStyle(el).backgroundImage; } catch (e) {}
    var m = /url\(["']?([^"')]+)["']?\)/.exec(bg || '');
    return (m && m[1].indexOf('data:') !== 0) ? abs(m[1]) : '';
  }
  // ảnh poster đại diện của một ô: trả về {src, el, alt}
  function posterOf(root) {
    var ims = root.querySelectorAll('img');
    for (var i = 0; i < ims.length; i++) {
      var r = rect(ims[i]);
      if (r.width >= 60 && r.height >= 70 && r.width <= 700) {
        var s = imgSrc(ims[i]);
        if (s) return { src: s, el: ims[i], alt: ims[i].getAttribute('alt') || '' };
      }
    }
    var els = root.querySelectorAll('div,span,a,figure');
    for (var j = 0; j < els.length; j++) {
      var r2 = rect(els[j]);
      if (r2.width >= 60 && r2.height >= 70 && r2.width <= 700) {
        var b = bgOf(els[j]);
        if (b) return { src: b, el: els[j], alt: '' };
      }
    }
    return null;
  }
  function labelOf(txt) {
    var m = /(PĐ\.?\s*\d+|TM\.?\s*\d+|FULL|Tập\s*\d+(?:\s*\/\s*\d+)?|\d+\s*\/\s*\d+\s*tập|HD|4K|CAM|Trailer)/i.exec(txt);
    return m ? norm(m[1]) : '';
  }
  function progressOf(card) {
    var t = norm(card.textContent);
    var m = /(\d+)\s*(?:m|p|phút)\s*\/\s*(\d+)\s*(?:m|p|phút)/i.exec(t);
    if (m && +m[2] > 0) return Math.max(0, Math.min(1, +m[1] / +m[2]));
    var els = card.querySelectorAll('[style*="width"]');
    for (var i = 0; i < els.length; i++) {
      var w = /width:\s*([\d.]+)%/.exec(els[i].getAttribute('style') || '');
      if (w && +w[1] > 0 && +w[1] < 100.5) return +w[1] / 100;
    }
    return 0;
  }
  function inChrome(el) {
    for (var p = el; p && p !== document.body; p = p.parentElement) {
      var tg = p.tagName;
      if (tg === 'HEADER' || tg === 'FOOTER' || tg === 'NAV') return true;
    }
    return false;
  }

  // ---- 1) các ô phim: mỗi ảnh poster nằm trong một liên kết cùng trang
  var anchors = document.querySelectorAll('a[href]');
  var cards = [], cardEls = [], seen = {};
  for (var i = 0; i < anchors.length; i++) {
    var a = anchors[i], href = abs(a.getAttribute('href'));
    if (!href || href.indexOf('http') !== 0 || !sameHost(href) || href.split('#')[0] === location.href.split('#')[0]) continue;
    if (inChrome(a)) continue;
    var p = posterOf(a);
    var holder = a;
    if (!p) continue;
    var ar = rect(a);
    if (ar.width < 60 || ar.height < 60) continue;
    if (seen[href] && seen[href] > 40) continue;
    seen[href] = (seen[href] || 0) + 1;
    // thẻ = tổ tiên lớn nhất chỉ chứa đúng một liên kết có poster (để lấy nhãn, tên, tiến độ)
    var card = a;
    while (card.parentElement && card.parentElement !== document.body) {
      var inner = card.parentElement.querySelectorAll('a[href]');
      var cnt = 0;
      for (var k = 0; k < inner.length; k++) if (posterOf(inner[k])) cnt++;
      if (cnt !== 1) break;
      card = card.parentElement;
    }
    var txt = norm(card.innerText || card.textContent);
    var title = norm(a.getAttribute('title') || p.alt || '');
    if (!title) {
      var lines = (card.innerText || '').split('\n').map(norm).filter(function (x) { return x.length > 2 && !/^(PĐ|TM|FULL|HD|4K|Tập|\d)/i.test(x); });
      if (lines.length) title = lines[lines.length - 1];
    }
    var r = rect(p.el.nodeType ? p.el : a);
    cardEls.push(card);
    cards.push({ title: title, url: href, poster: p.src, label: labelOf(txt), progress: progressOf(card), top: r.top + window.scrollY, left: r.left + window.scrollX, h: r.height });
  }

  // ---- 2) gom thành hàng theo toạ độ rồi gắn tiêu đề (chữ lớn nằm ngay phía trên)
  cards.sort(function (x, y) { return (x.top - y.top) || (x.left - y.left); });
  var lines = [];
  cards.forEach(function (c) {
    var L = lines.length ? lines[lines.length - 1] : null;
    if (L && Math.abs(c.top - L.top) < Math.max(24, L.h * 0.35)) L.items.push(c);
    else lines.push({ top: c.top, h: c.h, items: [c] });
  });
  lines.forEach(function (L) { L.items.sort(function (x, y) { return x.left - y.left; }); L.left = L.items[0].left; });

  // tiêu đề ứng viên
  var heads = [], hs = document.querySelectorAll('h1,h2,h3,h4,h5,h6,div,span,p,a,strong,b');
  for (var q = 0; q < hs.length; q++) {
    var el = hs[q];
    if (el.children.length > 3) continue;
    var t = norm(el.textContent);
    if (t.length < 3 || t.length > 50) continue;
    var rr = rect(el);
    if (rr.width < 20 || rr.height < 12 || rr.height > 90) continue;
    var cs; try { cs = getComputedStyle(el); } catch (e) { continue; }
    var fs = parseFloat(cs.fontSize) || 0, fw = parseInt(cs.fontWeight, 10) || 400;
    var isH = /^H[1-6]$/.test(el.tagName);
    if (!(isH || fs >= 16 || fw >= 600)) continue;
    if (el.querySelector('img')) continue;
    var inCard = false;
    for (var ce = 0; ce < cardEls.length; ce++) { if (cardEls[ce].contains(el)) { inCard = true; break; } }
    if (inCard) continue;
    if (/^(xem thêm|xem tất cả|tất cả|more|đăng nhập|đăng ký)$/i.test(t)) continue;
    heads.push({ t: t, el: el, top: rr.top + window.scrollY, bottom: rr.bottom + window.scrollY, left: rr.left + window.scrollX });
  }
  function moreOf(h) {
    var a = h.el.closest('a[href]') || h.el.querySelector('a[href]');
    var u = a ? abs(a.getAttribute('href')) : '';
    return (u && sameHost(u) && !seen[u]) ? u : '';
  }
  var rows = [];
  lines.forEach(function (L) {
    var best = null;
    heads.forEach(function (h) {
      var gap = L.top - h.bottom;
      if (gap < -6 || gap > 150) return;
      if (h.left > L.left + 160) return;
      if (!best || h.bottom > best.bottom || (h.bottom === best.bottom && h.left < best.left)) best = h;
    });
    var prev = rows.length ? rows[rows.length - 1] : null;
    if (best && prev && prev.__head === best) { prev.items = prev.items.concat(L.items); return; }
    if (!best && prev && (L.top - prev.__lastTop) < L.h * 2.4) { prev.items = prev.items.concat(L.items); prev.__lastTop = L.top; return; }
    rows.push({ title: best ? best.t : '', more: best ? moreOf(best) : '', items: L.items.slice(), __head: best, __lastTop: L.top });
  });
  var outRows = rows.map(function (r) {
    var rs = {}, its = [];
    r.items.forEach(function (c) { if (!rs[c.url]) { rs[c.url] = 1; its.push({ title: c.title, url: c.url, poster: c.poster, label: c.label, progress: c.progress }); } });
    return { title: r.title, more: r.more, items: its };
  }).filter(function (r) { return r.items.length > 0; });

  // ---- 3) thể loại / quốc gia: các liên kết ngắn trong thanh menu
  var genres = [], gseen = {};
  var navAs = document.querySelectorAll('header a[href], nav a[href], [class*="menu"] a[href], [class*="nav"] a[href], [id*="menu"] a[href]');
  for (var g = 0; g < navAs.length; g++) {
    var na = navAs[g], nt = norm(na.textContent), nu = abs(na.getAttribute('href'));
    if (nt.length < 2 || nt.length > 26 || !nu || !sameHost(nu)) continue;
    if (nu.split('#')[0].replace(/\/$/, '') === location.origin) continue;
    if (/đăng|login|tìm|search|menu|trang chủ|liên hệ|yêu cầu|tải app|ứng dụng|facebook|telegram|donate|chính sách|dmca|điều khoản/i.test(nt)) continue;
    if (na.querySelector('img') && nt.length < 3) continue;
    var key = nt.toLowerCase();
    if (gseen[key]) continue;
    gseen[key] = 1;
    genres.push({ n: nt, u: nu });
    if (genres.length >= 60) break;
  }

  // ---- 4) trang kế và ô tìm kiếm
  var next = '';
  var nx = document.querySelector('a[rel="next"], .next a[href], a.next[href], li.next a[href]');
  if (!nx) {
    var al = document.querySelectorAll('a[href]');
    for (var z = 0; z < al.length && !nx; z++) {
      var tz = norm(al[z].textContent);
      if (/^(sau|tiếp|trang sau|next|»|›|>|>>)$/i.test(tz)) nx = al[z];
    }
  }
  if (nx) { var nu2 = abs(nx.getAttribute('href')); if (nu2 && sameHost(nu2) && nu2.indexOf('javascript') !== 0) next = nu2; }
  var search = null;
  var inputs = document.querySelectorAll('form input[type="search"], form input[type="text"], form input:not([type])');
  for (var s = 0; s < inputs.length && !search; s++) {
    var inp = inputs[s], fm = inp.form;
    if (!fm || !inp.name) continue;
    var hint = (inp.placeholder || '') + ' ' + (inp.name || '') + ' ' + (fm.className || '') + ' ' + (fm.action || '');
    if (/tìm|search|keyword|q\b|tim-kiem|s\b/i.test(hint)) {
      var meth = (fm.method || 'get').toLowerCase();
      if (meth === 'get') search = { action: abs(fm.getAttribute('action') || location.href), name: inp.name };
    }
  }

  // kích hoạt tải ảnh/mục trễ: cuộn dần xuống
  try {
    window.__bs = (window.__bs || 0) + 1;
    var step = Math.max(300, window.innerHeight || 600);
    window.scrollTo(0, Math.min(document.documentElement.scrollHeight, window.__bs * step));
  } catch (e) {}

  return JSON.stringify({ rows: outRows, genres: genres, next: next, search: search,
    dbg: 'thẻ=' + cards.length + ' hàng=' + outRows.length + ' thể loại=' + genres.length });
})()
