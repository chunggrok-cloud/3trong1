(function () {
  // Điều hướng bằng phím mũi tên trên trang web.
  // Mỗi phim = một điểm dừng (viền sáng quanh poster), xuống/lên theo từng dòng, trang tự cuộn để dòng đang chọn nằm cố định.
  // Kotlin gọi: __tvNav.move('left'|'right'|'up'|'down'), __tvNav.act(), __tvNav.closeAd(), __tvNav.show(bool)
  if (window.__tvNav) return;
  var CUR = null, COLX = null, CACHE = null, CACHE_T = 0, ON = true, SAVED = [];
  var SNAP = 0.38;   // dòng đang chọn nằm ở khoảng 38% chiều cao màn hình tính từ trên xuống
  var st = document.createElement('style');
  st.id = '__tvnav-style';
  st.textContent = '.__tvfocus{outline:4px solid #6FA0FF !important;outline-offset:3px !important;border-radius:10px;box-shadow:0 0 0 8px rgba(111,160,255,.35),0 10px 24px rgba(0,0,0,.6) !important;transform:scale(1.06) !important;transform-origin:center center !important;transition:none !important;z-index:2147483000 !important}';
  (document.head || document.documentElement).appendChild(st);

  function vw() { return window.innerWidth || document.documentElement.clientWidth; }
  function vh() { return window.innerHeight || document.documentElement.clientHeight; }
  function txt(el) { return ((el.innerText || el.textContent || '') + '').replace(/\s+/g, ' ').trim(); }
  function isQC(el) { return /(^|[^A-Za-zÀ-ỹ])QC([^A-Za-zÀ-ỹ]|$)/.test(txt(el).slice(0, 140)); }
  function inDoc(el) { return el && el.isConnected; }
  function cssOf(el) { return getComputedStyle(el); }

  function visible(el, r) {
    if (r.width < 8 || r.height < 8) return false;
    var cs = cssOf(el);
    return !(cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) < 0.05);
  }

  // ảnh chính (poster / ảnh thu nhỏ) bên trong một phần tử: ảnh đủ lớn, không phải logo hay biểu tượng nhỏ
  function mainImage(el) {
    var best = null, ba = 0, list = el.tagName === 'IMG' ? [el] : Array.prototype.slice.call(el.querySelectorAll('img,picture,div,span'));
    for (var i = 0; i < list.length && i < 60; i++) {
      var x = list[i], r = x.getBoundingClientRect();
      if (r.width < 72 || r.height < 72) continue;
      var ok = x.tagName === 'IMG';
      if (!ok) { var bg = cssOf(x).backgroundImage; ok = bg && bg !== 'none' && bg.indexOf('url(') >= 0; }
      if (!ok) continue;
      var a = r.width * r.height;
      if (a < 9000) continue;
      if (a > ba) { ba = a; best = x; }
    }
    return best;
  }

  function collect() {
    var now = Date.now();
    if (CACHE && now - CACHE_T < 400) return CACHE;
    var raw = [], seen = new Set();
    var all = document.querySelectorAll('a[href],button,input,select,textarea,[role=button],[onclick],[tabindex],div,li,span,img,p,h3,h4,label');
    var n = Math.min(all.length, 4500);
    for (var i = 0; i < n; i++) {
      var el = all[i], tag = el.tagName;
      if (el.id === '__tvnav-style') continue;
      var native = tag === 'A' || tag === 'BUTTON' || tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' ||
        el.getAttribute('role') === 'button' || el.hasAttribute('onclick') ||
        (el.hasAttribute('tabindex') && el.getAttribute('tabindex') !== '-1');
      var ok = native;
      if (!ok) {
        if (cssOf(el).cursor === 'pointer') { var p = el.parentElement; ok = !p || cssOf(p).cursor !== 'pointer'; }
      }
      if (!ok || seen.has(el)) continue;
      if (tag === 'INPUT' && el.type === 'hidden') continue;
      var r = el.getBoundingClientRect();
      if (!visible(el, r)) continue;
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      if (cx >= 0 && cy >= 0 && cx < vw() && cy < vh()) {   // bị lớp khác che mất thì bỏ
        var top = document.elementFromPoint(cx, cy);
        if (top && top !== el && !el.contains(top) && !top.contains(el)) continue;
      }
      seen.add(el);
      raw.push(el);
    }
    var W = vw(), H = vh();
    // khối chứa nhiều điểm dừng hoặc quá lớn (banner, khung trang) thì bỏ khối, giữ các phần bên trong;
    // còn lại giữ phần tử ngoài cùng (cả thẻ phim là một điểm dừng)
    var rawSet = new Set(raw);
    var kept = raw.filter(function (el) {
      var inner = 0;
      for (var j = 0; j < raw.length; j++) { if (raw[j] !== el && el.contains(raw[j])) inner++; }
      var r = el.getBoundingClientRect();
      var big = r.width * r.height > W * H * 0.45;
      if (inner >= 5 || (big && inner >= 1)) return false;
      // có phần tử ngoài chứa nó và phần tử ngoài là một thẻ (không bị loại) thì bỏ phần trong
      var a = el.parentElement;
      while (a) {
        if (rawSet.has(a)) {
          var inn2 = 0;
          for (var k = 0; k < raw.length; k++) { if (raw[k] !== a && a.contains(raw[k])) inn2++; }
          var ar = a.getBoundingClientRect();
          if (!(inn2 >= 5 || (ar.width * ar.height > W * H * 0.45 && inn2 >= 1))) return false;
        }
        a = a.parentElement;
      }
      return true;
    });
    var units = [];
    kept.forEach(function (el) {
      var tag = el.tagName, cs = cssOf(el), r = el.getBoundingClientRect();
      var img = mainImage(el);
      var text = txt(el);
      var btnLike = tag === 'BUTTON' || tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' ||
        el.getAttribute('role') === 'button' || el.hasAttribute('aria-label') || !!el.querySelector('svg');
      var unit = { el: el, ring: el, r: r, qc: isQC(el), poster: false };
      if (img) { unit.ring = img; unit.r = img.getBoundingClientRect(); unit.poster = true; }
      else {
        if (!text && !btnLike) return;                                   // ảnh trang trí / logo không có chữ
        if (tag === 'A' && cs.display === 'inline' && r.height < 30 && !btnLike) return;   // liên kết chữ nằm trong đoạn văn
        if (tag === 'IMG') return;                                       // ảnh nhỏ (logo, biểu tượng) không phải nút
      }
      units.push(unit);
    });
    if (units.some(function (u) { return !u.qc; })) units = units.filter(function (u) { return !u.qc; });   // bỏ qua luồng (QC)
    // gom thành từng dòng theo độ cao
    units.forEach(function (u) { u.cx = u.r.left + u.r.width / 2; u.cy = u.r.top + u.r.height / 2; });
    units.sort(function (a, b) { return a.cy - b.cy; });
    var rows = [];
    units.forEach(function (u) {
      var row = rows.length ? rows[rows.length - 1] : null;
      var tol = Math.max(22, Math.min(u.r.height, row ? row.h : u.r.height) * 0.55);
      if (row && Math.abs(u.cy - row.cy) <= tol) { row.items.push(u); row.cy = (row.cy * (row.items.length - 1) + u.cy) / row.items.length; row.h = Math.min(row.h, u.r.height); }
      else rows.push({ items: [u], cy: u.cy, h: u.r.height });
    });
    rows.forEach(function (row) { row.items.sort(function (a, b) { return a.cx - b.cx; }); });
    CACHE = { units: units, rows: rows }; CACHE_T = now;
    return CACHE;
  }

  function scroller(el) {
    var a = el.parentElement;
    while (a && a !== document.body && a !== document.documentElement) {
      var cs = cssOf(a);
      if ((cs.overflowY === 'auto' || cs.overflowY === 'scroll') && a.scrollHeight > a.clientHeight + 4) return a;
      a = a.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }
  function scrollBy(el, dy) {
    var s = scroller(el);
    if (Math.abs(dy) < 4) return 0;
    var before = s.scrollTop;
    try { s.scrollTo({ top: before + dy, behavior: 'instant' }); } catch (e) { s.scrollTop = before + dy; }
    CACHE = null;
    return s.scrollTop - before;
  }

  function restoreSaved() {
    SAVED.forEach(function (o) { o.el.style.overflow = o.ov; if (o.pos) o.el.style.position = o.pos === 'x' ? '' : o.pos; });
    SAVED = [];
  }
  function setCur(u) {
    if (CUR && CUR.classList) CUR.classList.remove('__tvfocus');
    restoreSaved();
    CUR = u ? u.ring : null;
    CUR_UNIT = u || null;
    if (!CUR) return;
    // để viền và phần phóng to không bị khung cha cắt
    var a = CUR.parentElement, n = 0;
    while (a && n < 4) {
      var cs = cssOf(a);
      if (cs.overflow !== 'visible' && a !== document.body) { SAVED.push({ el: a, ov: a.style.overflow }); a.style.overflow = 'visible'; }
      a = a.parentElement; n++;
    }
    if (cssOf(CUR).position === 'static') { SAVED.push({ el: CUR, ov: CUR.style.overflow, pos: CUR.style.position || 'x' }); CUR.style.position = 'relative'; }
    if (ON) CUR.classList.add('__tvfocus');
  }
  var CUR_UNIT = null;

  function ensureHoriz(u) {
    var r = u.ring.getBoundingClientRect();
    if (r.left < 24 || r.right > vw() - 24) { try { u.ring.scrollIntoView({ block: 'nearest', inline: 'center', behavior: 'instant' }); } catch (e) {} CACHE = null; }
  }
  function snapRow(u) {
    var r = u.ring.getBoundingClientRect();
    var cy = r.top + r.height / 2;
    scrollBy(u.ring, cy - vh() * SNAP);
  }

  function findUnit(c, el) {
    for (var i = 0; i < c.units.length; i++) { if (c.units[i].ring === el || c.units[i].el === el) return c.units[i]; }
    return null;
  }
  function rowOf(c, u) {
    for (var i = 0; i < c.rows.length; i++) { if (c.rows[i].items.indexOf(u) >= 0) return i; }
    return -1;
  }
  function nearestInRow(row, x) {
    var best = null, bd = 1e9;
    row.items.forEach(function (u) { var d = Math.abs(u.cx - x); if (d < bd) { bd = d; best = u; } });
    return best;
  }
  function startUnit(c) {
    var best = null;
    for (var i = 0; i < c.rows.length; i++) {
      var row = c.rows[i];
      if (row.cy >= 0 && row.cy <= vh()) { best = row.items[0]; break; }
    }
    return best || (c.rows[0] && c.rows[0].items[0]);
  }

  function move(dir) {
    CACHE = null;
    var c = collect();
    if (!c.units.length) {
      if (dir === 'down') scrollBy(document.body, vh() * 0.7);
      if (dir === 'up') scrollBy(document.body, -vh() * 0.7);
      return 0;
    }
    var cu = inDoc(CUR) ? findUnit(c, CUR) : null;
    // phần tử đang chọn đã biến mất hoặc bị khuất khỏi màn hình: chọn lại phần tử gần nhất đang hiện
    if (cu) {
      var rr = cu.ring.getBoundingClientRect();
      if (rr.bottom < 0 || rr.top > vh()) cu = null;
    }
    if (!cu) {
      var s = startUnit(c);
      if (s) { setCur(s); COLX = s.cx; ensureHoriz(s); snapRow(s); }
      return 1;
    }
    var ri = rowOf(c, cu);
    if (dir === 'left' || dir === 'right') {
      var items = c.rows[ri].items, idx = items.indexOf(cu);
      var nx = items[idx + (dir === 'right' ? 1 : -1)];
      if (!nx) return 0;
      setCur(nx); COLX = nx.cx; ensureHoriz(nx);
      return 1;
    }
    var tri = ri + (dir === 'down' ? 1 : -1);
    if (tri < 0 || tri >= c.rows.length) {
      // không còn dòng nào trong trang: cuộn thêm một đoạn (trang có thể tải thêm), rồi thử lại một lần
      var moved = scrollBy(cu.ring, dir === 'down' ? vh() * 0.6 : -vh() * 0.6);
      if (!moved) return 0;
      c = collect();
      cu = findUnit(c, CUR);
      if (!cu) { var s2 = startUnit(c); if (s2) { setCur(s2); COLX = s2.cx; } return 1; }
      ri = rowOf(c, cu);
      tri = ri + (dir === 'down' ? 1 : -1);
      if (tri < 0 || tri >= c.rows.length) return 0;
    }
    var target = nearestInRow(c.rows[tri], COLX == null ? cu.cx : COLX);
    if (!target) return 0;
    setCur(target);
    snapRow(target);
    c = collect();
    var again = findUnit(c, CUR);
    if (again) COLX = COLX == null ? again.cx : COLX;
    return 1;
  }

  // ---- đóng quảng cáo dạng lớp phủ trong trang (cửa sổ mới đã được app chặn riêng)
  function sameSite(u) {
    try { return new URL(u, location.href).hostname.replace(/^www\./, '') === location.hostname.replace(/^www\./, ''); } catch (e) { return true; }
  }
  function adLike(el) {
    if (el.querySelector('video')) return false;
    if (window.__fchaiEl && (el.contains(window.__fchaiEl) || window.__fchaiEl.contains(el))) return false;
    if (el.querySelector('input,textarea,select')) return false;
    var fr = el.querySelectorAll('iframe');
    for (var i = 0; i < fr.length; i++) { if (fr[i].src && !sameSite(fr[i].src)) return true; }
    var as = el.querySelectorAll('a[href]');
    for (var j = 0; j < as.length; j++) { var h = as[j].getAttribute('href') || ''; if (/^https?:/i.test(h) && !sameSite(h)) return true; }
    var key = ((el.className && el.className.toString ? el.className.toString() : '') + ' ' + (el.id || '')).toLowerCase();
    return /(^|[\s_-])(ad|ads|adv|popup|pop|banner|promo|sponsor|qc|catfish|preroll)([\s_-]|$)/.test(key);
  }
  function findCloseBtn(el) {
    var c = el.querySelectorAll('button,a,div,span,i,svg');
    for (var i = 0; i < c.length; i++) {
      var x = c[i], t = txt(x), k = ((x.className && x.className.toString ? x.className.toString() : '') + ' ' + (x.id || '')).toLowerCase();
      var r = x.getBoundingClientRect();
      if (r.width < 6 || r.height < 6 || r.width > 160) continue;
      if (/^(×|✕|✖|x|X|close|đóng|bỏ qua|skip|tắt)$/i.test(t) || /close|dismiss|đóng|btn-x/.test(k)) return x;
    }
    return null;
  }
  function closeAd() {
    var W = vw(), H = vh(), best = null, ba = 0;
    var all = document.body ? document.body.querySelectorAll('div,aside,section,iframe,a,img') : [];
    for (var i = 0; i < all.length && i < 3000; i++) {
      var el = all[i], cs = cssOf(el);
      if (cs.position !== 'fixed' && cs.position !== 'absolute') continue;
      if (cs.display === 'none' || cs.visibility === 'hidden') continue;
      var r = el.getBoundingClientRect();
      var area = Math.max(0, Math.min(r.right, W) - Math.max(r.left, 0)) * Math.max(0, Math.min(r.bottom, H) - Math.max(r.top, 0));
      if (area < W * H * 0.06) continue;
      if (r.top <= 4 && r.height < H * 0.14 && r.width > W * 0.8) continue;
      var z = parseInt(cs.zIndex, 10) || 0;
      if (cs.position === 'absolute' && z < 100 && area < W * H * 0.5) continue;
      if (!adLike(el)) continue;
      if (area > ba) { ba = area; best = el; }
    }
    if (!best) return 0;
    var btn = findCloseBtn(best);
    if (btn) { try { btn.click(); } catch (e) {} }
    setTimeout(function () {
      if (best.isConnected && cssOf(best).display !== 'none') { try { best.remove(); } catch (e) {} }
      try { if (document.body.style.overflow === 'hidden') document.body.style.overflow = ''; } catch (e) {}
    }, 150);
    CACHE = null;
    return 1;
  }

  // OK: đóng quảng cáo nếu có; ngược lại trả toạ độ để app bấm thật vào phần tử đang sáng
  function act() {
    if (closeAd()) return JSON.stringify({ t: 'ad' });
    if (!inDoc(CUR)) {
      var c = collect(), s = startUnit(c);
      if (!s) return JSON.stringify({ t: 'none' });
      setCur(s); snapRow(s);
    }
    var r = CUR.getBoundingClientRect();
    if (r.top < 0 || r.bottom > vh()) { snapRow(CUR_UNIT || { ring: CUR }); r = CUR.getBoundingClientRect(); }
    var d = window.devicePixelRatio || 1;
    var tag = (CUR_UNIT && CUR_UNIT.el ? CUR_UNIT.el : CUR).tagName;
    return JSON.stringify({ t: 'tap', x: (r.left + r.width / 2) * d, y: (r.top + r.height / 2) * d, input: (tag === 'INPUT' || tag === 'TEXTAREA') ? 1 : 0 });
  }

  function show(on) {
    ON = !!on;
    if (CUR && CUR.classList) { if (ON) CUR.classList.add('__tvfocus'); else CUR.classList.remove('__tvfocus'); }
  }

  window.__tvNav = { move: move, act: act, closeAd: closeAd, show: show };
})();
